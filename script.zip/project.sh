#!/bin/bash

echo "=============================="
echo "1) Process Management"
echo "=============================="

ps aux

echo
echo "Enter the PID of the process you want to manage:"
read PID

echo "What do you want to do with process $PID ?"
echo "1) Terminate immediately"
echo "2) Sleep for a few seconds before termination"
read CHOICE


if [ "$CHOICE" -eq 2 ]; then
    echo "Enter the number of seconds to sleep before killing process $PID:"
    read SECS
    echo "Sleeping for $SECS seconds before killing process $PID..."
    sleep "$SECS"
    echo "Killing process $PID now..."
    kill "$PID"

elif [ "$CHOICE" -eq 1 ]; then
    echo "Terminating process $PID now..."
    kill "$PID"

else
    echo "Invalid choice. No action taken on process $PID."
fi

echo
echo "Updated list of running processes:"
ps aux
