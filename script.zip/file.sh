#!/bin/bash

echo "=============================="
echo "File Management"
echo "=============================="

echo "Enter the name of the new directory:"
read DIRNAME

mkdir "$DIRNAME"

echo "Moving all .txt files to $DIRNAME ..."
mv *.txt "$DIRNAME" 2>/dev/null

cd "$DIRNAME"

SUMMARY="summaryFile"

echo "Creating summaryFile..."
echo "CPIT260_VAR_G1" > "$SUMMARY"

echo "Processing text files..."

for FILE in *.txt
do
    if [ -f "$FILE" ]; then
        echo "------------------------------" >> "$SUMMARY"
        echo "File: $FILE" >> "$SUMMARY"
        echo "------------------------------" >> "$SUMMARY"
        head -n 2 "$FILE" >> "$SUMMARY"
        echo >> "$SUMMARY"
    fi
done

echo "summaryFile created successfully!"
